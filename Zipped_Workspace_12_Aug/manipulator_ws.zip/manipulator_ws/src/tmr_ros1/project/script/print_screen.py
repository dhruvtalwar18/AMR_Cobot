#!/usr/bin/env python
import sys
import copy
import rospy
import moveit_commander
import moveit_msgs.msg
from std_msgs.msg import String

def main():
  try:
      ch = raw_input("gripper or manipulator? ")
      # rospy.init_node('print_to_screen', anonymous=True)
      if ch == 'gripper':
          hue = rospy.set_param('/choice', 'true')
      else:
          hue = rospy.set_param('/choice', 'false')

      rospy.loginfo(hue)
      print(hue)
  # except rospy.ROSInterruptException:
  #   return
  except KeyboardInterrupt:
    return

if __name__ == '__main__':
  main()
