#!/usr/bin/env python
import sys
import copy
import rospy
import math
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
from sensor_msgs.msg import JointState
from moveit_msgs.msg import MotionPlanRequest
from moveit_commander.conversions import pose_to_list

#publisher functions begin
def talker_angles():
    pub_angles = rospy.Publisher('publish_angles', JointState, queue_size=10)
    joint_state_object = JointState()

    input_arr = map(float, raw_input("Angles (input in a single line): ").split())
    for i in range(6):
        input_arr[i] = math.radians(input_arr[i])

    joint_state_object.position = input_arr
    pub_angles.publish(joint_state_object)

def talker_vel():
    pub_velocity = rospy.Publisher('publish_velocities', MotionPlanRequest, queue_size=10)
    motion_plan_object = MotionPlanRequest()
    motion_plan_object.max_velocity_scaling_factor = input('Velocity scaling factor (between 0 and 1): ')
    pub_velocity.publish(motion_plan_object)
#publisher functions end

#callback and listener functions begin
def callback_angles(joint_object):
    global joint_goal
    joint_goal = joint_object.position

def listener_angles():
    sub_angles = rospy.Subscriber('publish_angles', JointState, callback_angles)
    talker_angles()
    rospy.rostime.wallsleep(0.5)
    sub_angles.unregister()

def callback_vel(motion_plan_obj):
    global scaling_factor
    scaling_factor = motion_plan_obj.max_velocity_scaling_factor

def listener_vel():
    sub_vel = rospy.Subscriber('publish_velocities', MotionPlanRequest, callback_vel)
    talker_vel()
    rospy.rostime.wallsleep(0.5)
    sub_vel.unregister()
#callback and listener functions end

#subscriber class begin
class subscriber(object):

  def __init__(self):
      super(subscriber, self).__init__()

      moveit_commander.roscpp_initialize(sys.argv)
      rospy.init_node('joint_angles_subscriber', anonymous=True)

      robot = moveit_commander.RobotCommander()
      scene = moveit_commander.PlanningSceneInterface()

      group_name = "manipulator"
      move_group = moveit_commander.MoveGroupCommander(group_name)
      display_trajectory_publisher = rospy.Publisher('/move_group/display_planned_path', moveit_msgs.msg.DisplayTrajectory, queue_size=20)

      planning_frame = move_group.get_planning_frame()
      eef_link = move_group.get_end_effector_link()
      group_names = robot.get_group_names()

      self.move_group = move_group

  def go_to_joint_state(self):
      move_group = self.move_group

      global joint_goal, scaling_factor
      scaling_factor = 1
      joint_goal = move_group.get_current_joint_values()

      listener_angles()
      listener_vel()

      move_group.set_max_velocity_scaling_factor(scaling_factor)
      move_group.go(joint_goal, wait=True)
      move_group.stop()
#subscriber class end

def main():
  try:
      while True:
          subscriber_object = subscriber()
          print "============ Press `Enter` to execute a movement using a joint state goal: "
          raw_input()
          subscriber_object.go_to_joint_state()
          ch = raw_input("Do you want to give more inputs (y/n): ")
          if ch == 'n':
              break

  except rospy.ROSInterruptException:
    return
  except KeyboardInterrupt:
    return

if __name__ == '__main__':
    try:
        main()
    except rospy.ROSInterruptException:
        pass
