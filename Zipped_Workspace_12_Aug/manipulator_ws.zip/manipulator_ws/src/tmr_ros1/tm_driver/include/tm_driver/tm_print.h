#pragma once
#include <ros/ros.h>

int print_debug(const char* fmt, ...);
int print_info(const char* fmt, ...);
int print_warn(const char* fmt, ...);
int print_error(const char* fmt, ...);
int print_fatal(const char* fmt, ...);
